<?php
    try {
        $pdo = new PDO("sqlite:star_wars.db");
    }
    catch (PDOException $e) {
        throw new PDOException($e->getMessage(), (int)$e->getCode());
    }

    $query = "SELECT * FROM film";
    $result = $pdo->query($query);

    while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
        echo 'Film Title: '.htmlspecialchars($row['film_title']).'<br>';
    } ?>